﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InputProgram
{
    /// <summary>
    /// This program  tests the validity of numeric values given by the user
    /// </summary>
    class InputProgram
    {
        static void Main (string[] args)
        {
            // Declare and create an object of the Menu class
             Menu menu = new Menu ( );
            // Call the start method of the Menu class to 
            // get started.
            menu.ShowMenu ( );
        }
    }
}
